package com.example.bankindonesia;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

    public class listbankindonesia extends RecyclerView.Adapter<listbankindonesia.ListViewHolder> {
        private OnItemClickCallback onItemClickCallback;

        private ArrayList<bankindonesia> listbankindonesia;


        public listbankindonesia(ArrayList<bankindonesia> list) {
            this.listbankindonesia = list;
        }
        public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
            this.onItemClickCallback = onItemClickCallback;
        }

        @NonNull
        @Override
        public listbankindonesia.ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bank, viewGroup, false);
            return new ListViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final listbankindonesia.ListViewHolder holder, int position) {
            bankindonesia bankindonesia = listbankindonesia.get(position);
            Glide.with(holder.itemView.getContext())
                    .load(bankindonesia.getPhoto())
                    .apply(new RequestOptions().override(55, 55))
                    .into(holder.imgPhoto);
            holder.tvName.setText(bankindonesia.getName());
            holder.tvDetail.setText(bankindonesia.getDetail());
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClickCallback.onItemClicked(listbankindonesia.get(holder.getAdapterPosition()));
                }
            });

        }

        @Override
        public int getItemCount() {
            return listbankindonesia.size();
        }

        public class ListViewHolder extends RecyclerView.ViewHolder {
            ImageView imgPhoto;
            TextView tvName, tvDetail;

            public ListViewHolder(@NonNull View itemView) {
                super(itemView);
                imgPhoto = itemView.findViewById(R.id.img_item_photo);
                tvName = itemView.findViewById(R.id.tv_item_name);
                tvDetail = itemView.findViewById(R.id.tv_item_detail);
            }
        }

        public interface OnItemClickCallback {
            void onItemClicked(bankindonesia data);
        }
    }
