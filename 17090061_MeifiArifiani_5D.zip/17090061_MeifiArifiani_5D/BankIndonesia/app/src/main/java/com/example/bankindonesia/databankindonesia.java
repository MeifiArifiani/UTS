package com.example.bankindonesia;

import java.util.ArrayList;

public class databankindonesia {
    private static String[] bankNames = {
            "Bank Bca",
            "Bank Bni",
            "Bank Bri",
            "Bank Btn",
            "Bank Btpn",
            "Bank Bukopin",
            "Bank Cimbniaga",
            "Bank Danamon",
            "Bank Jateng",
            "Bank Mandiri"

    };

    private static String[] detailbank = {
            "Pada tahun 1955 NV Perseroan Dagang Dan Industrie Semarang Knitting Factory berdiri sebagai cikal bakal Bank Central Asia BCA. BCA didirikan oleh Sudono Salim pada tanggal 21 Februari 1957 dan berkantor pusat di Jakarta.",
            "Bank Negara Indonesia, Tbk selanjutnya disebut BNI atau Bank pada awalnya didirikan di Indonesia sebagai Bank sentral dengan nama Bank Negara Indonesia berdasarkan Peraturan Pemerintah Pengganti Undang-Undang No. 2 tahun 1946 tanggal 5 Juli 1946.",
            "BRI merupakan salah satu bank tertua di Indonesia. BRI didirikan di Purwokerto oleh Raden Bei Aria Wirjaatmadja dengan nama De Poerwokertosche Hulp en Spaarbank der Inlandsche Hoofden atau Bank Bantuan dan Simpanan Milik Kaum Priyayi Purwokerto pada 16 Desember 1895.",
            "Cikal bakal BTN dimulai dengan didirikannya Postspaarbank di Batavia pada tahun 1897. Pada tahun 1942, sejak masa pendudukan Jepang di Indonesia, bank ini dibekukan dan digantikan dengan Tyokin Kyoku atau Chokinkyoku. Setelah proklamasi kemerdekaan Indonesia bank ini diambil alih oleh pemerintah Indonesia dan diubah menjadi Kantor Tabungan Pos.",
            "BTN dimulai dengan didirikannya Postspaarbank di Batavia pada tahun 1897. Pada tahun 1942, sejak masa pendudukan Jepang di Indonesia, bank ini dibekukan dan digantikan dengan Tyokin Kyoku atau Chokinkyoku. Setelah proklamasi kemerdekaan Indonesia bank ini diambil alih oleh pemerintah Indonesia dan diubah menjadi Kantor Tabungan Pos.",
            "Ketujuh serangkai tersebut kemudian mendirikan Perkumpulan Bank Pegawai Pensiunan Militer selanjutnya disebut BAPEMIL dengan status usaha sebagai perkumpulan yang menerima simpanan dan memberikan pinjaman kepada para anggotanya.",
            "CIMB Niaga adalah sebuah bank yang berdiri pada tahun 1955.  Saat ini CIMB Niaga merupakan bank terbesar keempat di Indonesia dilihat dari sisi aset, dan diakui prestasi dan keunggulannya di bidang pelayanan nasabah dan pengembangan manajemen. Saat ini mayoritas saham Bank CIMB Niaga dimiliki oleh CIMB Group.",
            "Bank Danamon didirikan pada tanggal 16 Juli 1956 dengan nama PT Bank Kopra Indonesia. Pada tahun 1976 nama bank ini berubah menjadi PT Bank Danamon Indonesia.",
            "Bank Pembangunan Daerah Jawa Tengah pertama kali didirikan di Semarang berdasarkan Surat Persetujuan Menteri Pemerintah Umum & Otonomi Daerah No. DU 57/1/35 tanggal 13 Maret 1963 dan ijin usaha dari Menteri Urusan Bank Sentral No. 4/Kep/MUBS/63 tanggal 14 Maret 1963 sebagai landasan operasional Jawa Tengah. Operasional pertama dimulai pada tanggal 6 April 1963 dengan menempati Gedung Bapindo, Jl. Pahlawan No. 3 Semarang sebagai Kantor Pusat.",
            "Bank Mandiri merupakan salah satu bank terbesar yang beroperasi di Indonesia. Selain telah memiliki banyak nasabah dan memiliki kantor cabang di seluruh Indonesia, Bank Mandiri juga telah meraih banyak prestasi di dunia perbankan. Pada tahun 2016, Bank Mandiri menjadi bank pertama di Indonesia yang memiliki jumlah aset sebesar 1000 triliun."

    };

    private static int[] bankImages = {
            R.drawable.bca,
            R.drawable.bni,
            R.drawable.bri,
            R.drawable.btn,
            R.drawable.btpn,
            R.drawable.bukopin,
            R.drawable.cimbniaga,
            R.drawable.danamon,
            R.drawable.jateng,
            R.drawable.mandiri
    };


    static ArrayList<bankindonesia> getListData() {
        ArrayList<bankindonesia> list = new ArrayList<>();
        for (int position = 0; position < bankNames.length; position++) {
            bankindonesia bankindonesia = new bankindonesia();
            bankindonesia.setName(bankNames[position]);
            bankindonesia.setDetail(detailbank[position]);
            bankindonesia.setPhoto(bankImages[position]);
            list.add(bankindonesia);
        }
        return list;
    }
}
