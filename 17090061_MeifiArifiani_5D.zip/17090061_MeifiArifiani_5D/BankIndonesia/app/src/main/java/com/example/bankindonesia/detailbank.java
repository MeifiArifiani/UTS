package com.example.bankindonesia;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

public class detailbank extends AppCompatActivity {
    Toolbar back;
    ImageView imagebank;
    TextView namebank, detailbank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_bank);

        imagebank = findViewById(R.id.img_item_photo);
        namebank = findViewById(R.id.tv_item_name);
        detailbank = findViewById(R.id.tv_item_detail);


        back = findViewById(R.id.toolbarback);
        setSupportActionBar(back);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        int photo = getIntent().getIntExtra("BankImages", 0);
        String nama = getIntent().getStringExtra("BankNames");
        String deskripsi = getIntent().getStringExtra("DetailBank");
        imagebank.setImageResource(photo);
        namebank.setText(nama);
        detailbank.setText(deskripsi);
    }

    private void setSupportActionBar(Toolbar back) {
    }
}
